from flask import Flask, render_template
app = Flask(__name__)
@app.route("/log")
def login():
   return render_template("login.html")
@app.route("/customermaster")
def a():
   return render_template("customermaster.html")
@app.route("/booking")
def b():
   return render_template("booking.html")
@app.route("/courierdetails")
def c():
   return render_template("courierdetails.html")
@app.route("/cviewall")
def d():
   return render_template("cviewall.html")
if __name__ == '__main__':
   app.run(debug = True)
