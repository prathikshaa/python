from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/courierproject'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
@app.route("/login")
def login():
   return render_template("login.html")
@app.route("/register")
def aa():
   return render_template("register.html")
@app.route("/customermaster")
def a():
   return render_template("customermaster.html")
@app.route("/booking")
def b():
   return render_template("booking.html")
@app.route("/courierdetails")
def c():
   return render_template("courierdetails.html")
@app.route("/cviewall")
def d():
   return render_template("cviewall.html")
@app.route("/admin")
def admin():
   return render_template("admin.html")
@app.route("/users")
def users():
   return render_template("users.html",register=register.query.all())
class register(db.Model):
	id = db.Column('customer_id', db.Integer, primary_key = True)
	customername = db.Column(db.String(10))
	password = db.Column(db.String(50))
	conformpassword = db.Column(db.String(50)) 
	gender = db.Column(db.String(60))
	address = db.Column(db.String(50))
	email = db.Column(db.String(50))
	phoneno = db.Column(db.String(10))
	def __init__(self,customername,password,conformpassword,gender,address,email,phoneno):
		self.customername = customername
		self.password = password
		self.conformpassword = conformpassword
		self.gender = gender
		self.address = address
		self.email = email
		self.phoneno = phoneno
	@app.route('/register', methods = ['GET', 'POST'])
	def reg():
		if request.method == 'POST':  
			if not request.form['customername'] or not request.form['password'] or not request.form['conformpassword']or not request.form['gender'] or not request.form['address']or not request.form['email']or not request.form['phoneno']:
				flash('Please enter all the fields', 'error')
			else:
				customer=register(request.form['customername'],request.form['password'],request.form['conformpassword'],request.form['gender'],request.form['address'], request.form['email'],request.form['phoneno'])
				db.session.add(customer)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('login'))
		return render_template('register.html') 
@app.route('/admin1', methods = ['POST','GET'])
def admin1():
	if request.method=='GET':
		return render_template('login.html')
	customername = request.form['UserId']
	password = request.form['Password']
	customer=register.query.filter_by(customername=customername,password=password).first()
	if request.form['Password'] == 'admin' and request.form['UserId'] == 'admin':
		return render_template("admin.html")
	if customer is None:
		return render_template("login.html")
	else:
		return render_template("booking.html")
class bookings(db.Model):
	id = db.Column('customer_id', db.Integer, primary_key = True)
	customername = db.Column(db.String(50))
	password = db.Column(db.String(60))
	conformpassword = db.Column(db.String(60)) 
	gender = db.Column(db.String(60))
	address = db.Column(db.String(50))
	email = db.Column(db.String(50))
	phoneno = db.Column(db.String(100))
	def __init__(self,customername,password,conformpassword,gender,address,email,phoneno):
		self.customername = customername
		self.password = password
		self.conformpassword = conformpassword
		self.gender = gender
		self.address = address
		self.email = email
		self.phoneno = phoneno
	@app.route('/register', methods = ['GET', 'POST'])
	def booking():
		if request.method == 'POST':  
			if not request.form['customername'] or not request.form['password'] or not request.form['conformpassword']or not request.form['gender'] or not request.form['address']or not request.form['email']or not request.form['phoneno']:
				flash('Please enter all the fields', 'error')
			else:
				customer=bookings(request.form['customername'],request.form['password'],request.form['conformpassword'],request.form['gender'],request.form['address'], request.form['email'],request.form['phoneno'])
				db.session.add(customer)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('customermaster'))
		return render_template('booking.html')    
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
