from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:ROOT@localhost/courier'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
@app.route('/login')
def login():
   return render_template("login.html")
@app.route('/registers')
def registers():
   return render_template('registers.html',indexed=indexed.query.order_by(indexed.id.desc()).limit(1).all())
@app.route('/customermaster')
def customermaster():
   return render_template("customermaster.html")  
@app.route('/searchdispatch')
def searchdispatch():
   return render_template("searchdispatch.html",cbook=cbook.query.all())  
@app.route('/courierbooking')
def courierbooking():
   return render_template("courierbooking.html",cbook=cbook.query.order_by(cbook.id.desc()).limit(1).all())
@app.route('/courierdetails')
def c():
   return render_template('courierdetails.html')
@app.route('/cview')
def cview(name):
   return render_template('cview.html',cbook=cbook.query.filter_by(ParcelNo='%d'%name))
@app.route('/cviewall')
def cviewall():
   return render_template('cviewall.html',cbook=cbook.query.all())
@app.route('/employeemaster')
def employeemaster():
   return render_template("employeemaster.html")
@app.route('/empregister')
def empregister():
   return render_template('empregister.html')
@app.route('/employeedetails')
def employeedetails():
   return render_template('employeedetails.html')
@app.route('/eviewall/<int:name>')
def eviewall(name):
   return render_template('eviewall.html',empreg=empreg.query.filter_by(EmployeeId='%d'%name))
@app.route('/eall')
def eall():
   return render_template('eall.html',empreg=empreg.query.all())
@app.route('/adminmaster')
def adminmaster():
   return render_template('adminmaster.html')
@app.route('/despatchcourier')
def despatchcourier():
   return render_template('despatchcourier.html',cbook=cbook.query.filter_by(dis=1))
@app.route('/ship')
def ship():
   return render_template('ship.html')
@app.route('/shipview/<int:name>')
def shipview(name):
   return render_template('shipview.html',cbook=cbook.query.filter_by(ParcelNo='%d'%name))
class indexed(db.Model):
	id = db.Column('customer_id', db.Integer, primary_key = True)
	customerid = db.Column(db.String(50))
	customername = db.Column(db.String(50))
	password = db.Column(db.String(50))
	conformpassword = db.Column(db.String(50)) 
	gender = db.Column(db.String(60))
	address = db.Column(db.String(50))
	email = db.Column(db.String(50))
	phoneno = db.Column(db.String(50))
	def __init__(self,customerid,customername,password,conformpassword,gender,address,email,phoneno):
		self.customerid = customerid
		self.customername = customername
		self.password = password
		self.conformpassword = conformpassword
		self.gender = gender
		self.address = address
		self.email = email
		self.phoneno = phoneno
	@app.route('/register', methods = ['GET', 'POST'])
	def reg():
		if request.method == 'POST':  
			if not request.form['customerid'] or not request.form['customername'] or not request.form['password'] or not request.form['conformpassword']or not request.form['gender'] or not request.form['address']or not request.form['email']or not request.form['phoneno']:
				flash('Please enter all the fields', 'error')
			else:
				customer=indexed(request.form['customerid'],request.form['customername'],request.form['password'],request.form['conformpassword'],request.form['gender'],request.form['address'], request.form['email'],request.form['phoneno'])
				db.session.add(customer)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('login'))
		return render_template('register.html') 
@app.route('/admin1', methods = ['POST','GET'])
def admin1():
	if request.method=='GET':
		return render_template('login.html')
	customerid = request.form['UserId']
	password = request.form['Password']
	customer=indexed.query.filter_by(customerid=customerid,password=password).first()
	emp=empreg.query.filter_by(EmployeeId=customerid,Password=password).first()
	if request.form['Password'] == 'admin' and request.form['UserId'] == 'admin':
		return render_template("adminmaster.html")
	if customer is not None:
		return render_template("customermaster.html")
	elif emp is not None:
		return render_template("employeemaster.html")
	else:
		return render_template("login.html")
@app.route('/value/<id>', methods=['POST','GET'])
def value(id):
	demo=cbook.query.get(id)
	demo.dis=0
	db.session.commit()
	return redirect(url_for('despatchcourier'))
@app.route('/eviewal', methods=['POST','GET'])
def eviewal():
	if request.method=='POST':
		View = request.form['View']
		return redirect(url_for('eviewall',name=View))
@app.route('/cview', methods=['POST','GET'])
def cviewal():
	if request.method=='POST':
		View = request.form['View']
		return redirect(url_for('cview',name=View))
class cbook(db.Model):
	id = db.Column('demo_id', db.Integer, primary_key = True)
	ParcelNo = db.Column(db.String(50))
	BookingDate = db.Column(db.String(50))
	Name = db.Column(db.String(50))
	Address = db.Column(db.String(50)) 
	State = db.Column(db.String(50)) 
	PhoneNo = db.Column(db.String(60))
	TName = db.Column(db.String(50))
	TAddress = db.Column(db.String(50))
	TState = db.Column(db.String(50))
	TPhoneNo = db.Column(db.String(50))
	Weight = db.Column(db.String(50))
	Amount = db.Column(db.String(50))
	ModeOfTranceSport = db.Column(db.String(50))
	dis=db.Column(db.Integer,default=1)
	def __init__(self, ParcelNo,BookingDate,Name,Address,State,PhoneNo,TName,TAddress,TState,TPhoneNo,Weight,Amount,ModeOfTranceSport,dis):
		self.ParcelNo = ParcelNo
		self.BookingDate = BookingDate
		self.Name = Name
		self.Address = Address
		self.State = State
		self.PhoneNo = PhoneNo
		self.TName = TName
		self.TAddress = TAddress
		self.TState = TState
		self.TPhoneNo = TPhoneNo
		self.Weight = Weight
		self.Amount = Amount
		self.ModeOfTranceSport = ModeOfTranceSport
		self.dis = dis
	@app.route('/courierbooking', methods = ['GET', 'POST'])
	def book():
		if request.method == 'POST':  
			if not request.form['ParcelNo'] or not request.form['BookingDate'] or not request.form['Name'] or not request.form['Address'] or not request.form['State'] or not request.form['PhoneNo'] or not request.form['TName'] or not request.form['TAddress'] or not request.form['TState'] or not request.form['TPhoneNo'] or not request.form['Weight'] or not request.form['Amount'] or not request.form['ModeOfTranceSport']or not request.form['dis']:
				flash('Please enter all the fields', 'error')
			else:
				demo=cbook(request.form['ParcelNo'],request.form['BookingDate'],request.form['Name'],request.form['Address'],request.form['State'],request.form['PhoneNo'], request.form['TName'],request.form['TAddress'],request.form['TState'], request.form['TPhoneNo'], request.form['Weight'],request.form['Amount'],request.form['ModeOfTranceSport'],request.form['dis'])
				db.session.add(demo)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('customermaster'))
		return render_template('courierbooking.html') 		
class empreg(db.Model):
	id = db.Column('emp', db.Integer, primary_key = True)
	EmployeeId = db.Column(db.String(50))
	EmployeeName = db.Column(db.String(50))
	Password = db.Column(db.String(50))
	ConformPassword = db.Column(db.String(50)) 
	Gender = db.Column(db.String(50)) 
	Address = db.Column(db.String(60))
	Email = db.Column(db.String(50))
	PhoneNo = db.Column(db.String(50))
	Qualification = db.Column(db.String(10))
	Designation = db.Column(db.String(50))
	Salary = db.Column(db.String(50))
	BasicPay = db.Column(db.String(50))
	def __init__(self, EmployeeId, EmployeeName, Password, ConformPassword, Gender, Address, Email, PhoneNo, Qualification, Designation, Salary, BasicPay):
		self.EmployeeId = EmployeeId
		self.EmployeeName = EmployeeName
		self.Password = Password
		self.ConformPassword = ConformPassword
		self.Gender = Gender
		self.Address = Address
		self.Email = Email
		self.PhoneNo = PhoneNo
		self.Qualification = Qualification
		self.Designation = Designation
		self.Salary = Salary
		self.BasicPay = BasicPay
	@app.route('/adminmaster', methods = ['GET', 'POST'])
	def emp():
		if request.method == 'POST':  
			if not request.form['EmployeeId'] or not request.form['EmployeeName'] or not request.form['Password'] or not request.form['ConformPassword'] or not request.form['Gender'] or not request.form['Address'] or not request.form['Email'] or not request.form['PhoneNo'] or not request.form['Qualification'] or not request.form['Designation'] or not request.form['Salary'] or not request.form['BasicPay']:
				flash('Please enter all the fields', 'error')
			else:
				emp=empreg(request.form['EmployeeId'],request.form['EmployeeName'],request.form['Password'],request.form['ConformPassword'],request.form['Gender'],request.form['Address'], request.form['Email'],request.form['PhoneNo'],request.form['Qualification'], request.form['Designation'], request.form['Salary'],request.form['BasicPay'])
				db.session.add(emp)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('adminmaster'))
		return render_template('empregister.html') 		
		
		
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
